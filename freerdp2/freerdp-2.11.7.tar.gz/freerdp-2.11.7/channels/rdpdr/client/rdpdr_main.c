/**
 * FreeRDP: A Remote Desktop Protocol Implementation
 * Device Redirection Virtual Channel
 *
 * Copyright 2010-2011 Vic Lee
 * Copyright 2010-2012 Marc-Andre Moreau <marcandre.moreau@gmail.com>
 * Copyright 2015-2016 Thincast Technologies GmbH
 * Copyright 2015 DI (FH) Martin Haimberger <martin.haimberger@thincast.com>
 * Copyright 2016 Armin Novak <armin.novak@thincast.com>
 * Copyright 2016 David PHAM-VAN <d.phamvan@inuvika.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <winpr/crt.h>
#include <winpr/sysinfo.h>
#include <winpr/stream.h>

#include <winpr/sspicli.h>

#include <freerdp/types.h>
#include <freerdp/constants.h>
#include <freerdp/channels/log.h>
#include <freerdp/channels/rdpdr.h>

#ifdef _WIN32
#include <windows.h>
#include <dbt.h>
#else
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#endif

#ifdef __MACOSX__
#include <CoreFoundation/CoreFoundation.h>
#include <stdio.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include "rdpdr_capabilities.h"

#include "devman.h"
#include "irp.h"

#include "rdpdr_main.h"

typedef struct _DEVICE_DRIVE_EXT DEVICE_DRIVE_EXT;
/* IMPORTANT: Keep in sync with DRIVE_DEVICE */
struct _DEVICE_DRIVE_EXT
{
	DEVICE device;
	WCHAR* path;
	BOOL automount;
};

static const char* rdpdr_packetid_string(UINT16 packetid)
{
	switch (packetid)
	{
		case PAKID_CORE_SERVER_ANNOUNCE:
			return "PAKID_CORE_SERVER_ANNOUNCE";
		case PAKID_CORE_CLIENTID_CONFIRM:
			return "PAKID_CORE_CLIENTID_CONFIRM";
		case PAKID_CORE_CLIENT_NAME:
			return "PAKID_CORE_CLIENT_NAME";
		case PAKID_CORE_DEVICELIST_ANNOUNCE:
			return "PAKID_CORE_DEVICELIST_ANNOUNCE";
		case PAKID_CORE_DEVICE_REPLY:
			return "PAKID_CORE_DEVICE_REPLY";
		case PAKID_CORE_DEVICE_IOREQUEST:
			return "PAKID_CORE_DEVICE_IOREQUEST";
		case PAKID_CORE_DEVICE_IOCOMPLETION:
			return "PAKID_CORE_DEVICE_IOCOMPLETION";
		case PAKID_CORE_SERVER_CAPABILITY:
			return "PAKID_CORE_SERVER_CAPABILITY";
		case PAKID_CORE_CLIENT_CAPABILITY:
			return "PAKID_CORE_CLIENT_CAPABILITY";
		case PAKID_CORE_DEVICELIST_REMOVE:
			return "PAKID_CORE_DEVICELIST_REMOVE";
		case PAKID_CORE_USER_LOGGEDON:
			return "PAKID_CORE_USER_LOGGEDON";
		case PAKID_PRN_CACHE_DATA:
			return "PAKID_PRN_CACHE_DATA";
		case PAKID_PRN_USING_XPS:
			return "PAKID_PRN_USING_XPS";
		default:
			return "UNKNOWN";
	}
}

static const char* rdpdr_state_str(enum RDPDR_CHANNEL_STATE state)
{
	switch (state)
	{
		case RDPDR_CHANNEL_STATE_INITIAL:
			return "RDPDR_CHANNEL_STATE_INITIAL";
		case RDPDR_CHANNEL_STATE_ANNOUNCE:
			return "RDPDR_CHANNEL_STATE_ANNOUNCE";
		case RDPDR_CHANNEL_STATE_ANNOUNCE_REPLY:
			return "RDPDR_CHANNEL_STATE_ANNOUNCE_REPLY";
		case RDPDR_CHANNEL_STATE_NAME_REQUEST:
			return "RDPDR_CHANNEL_STATE_NAME_REQUEST";
		case RDPDR_CHANNEL_STATE_SERVER_CAPS:
			return "RDPDR_CHANNEL_STATE_SERVER_CAPS";
		case RDPDR_CHANNEL_STATE_CLIENT_CAPS:
			return "RDPDR_CHANNEL_STATE_CLIENT_CAPS";
		case RDPDR_CHANNEL_STATE_CLIENTID_CONFIRM:
			return "RDPDR_CHANNEL_STATE_CLIENTID_CONFIRM";
		case RDPDR_CHANNEL_STATE_READY:
			return "RDPDR_CHANNEL_STATE_READY";
		case RDPDR_CHANNEL_STATE_USER_LOGGEDON:
			return "RDPDR_CHANNEL_STATE_USER_LOGGEDON";
		default:
			return "RDPDR_CHANNEL_STATE_UNKNOWN";
	}
}

static const char* rdpdr_device_type_string(UINT32 type)
{
	switch (type)
	{
		case RDPDR_DTYP_SERIAL:
			return "serial";
		case RDPDR_DTYP_PRINT:
			return "printer";
		case RDPDR_DTYP_FILESYSTEM:
			return "drive";
		case RDPDR_DTYP_SMARTCARD:
			return "smartcard";
		case RDPDR_DTYP_PARALLEL:
			return "parallel";
		default:
			return "UNKNOWN";
	}
}

static const char* support_str(BOOL val)
{
	if (val)
		return "supported";
	return "not found";
}

static const char* rdpdr_caps_pdu_str(UINT32 flag)
{
	switch (flag)
	{
		case RDPDR_DEVICE_REMOVE_PDUS:
			return "RDPDR_USER_LOGGEDON_PDU";
		case RDPDR_CLIENT_DISPLAY_NAME_PDU:
			return "RDPDR_CLIENT_DISPLAY_NAME_PDU";
		case RDPDR_USER_LOGGEDON_PDU:
			return "RDPDR_USER_LOGGEDON_PDU";
		default:
			return "RDPDR_UNKNONW";
	}
}

static BOOL rdpdr_check_extended_pdu_flag(rdpdrPlugin* rdpdr, UINT32 flag)
{
	WINPR_ASSERT(rdpdr);

	const BOOL client = (rdpdr->clientExtendedPDU & flag) != 0;
	const BOOL server = (rdpdr->serverExtendedPDU & flag) != 0;

	if (!client || !server)
	{
		WLog_Print(rdpdr->log, WLOG_WARN, "Checking ExtendedPDU::%s, client %s, server %s",
		           rdpdr_caps_pdu_str(flag), support_str(client), support_str(server));
		return FALSE;
	}
	return TRUE;
}

BOOL rdpdr_state_advance(rdpdrPlugin* rdpdr, enum RDPDR_CHANNEL_STATE next)
{
	WINPR_ASSERT(rdpdr);

	if (next != rdpdr->state)
		WLog_Print(rdpdr->log, WLOG_DEBUG, "[RDPDR] transition from %s to %s",
		           rdpdr_state_str(rdpdr->state), rdpdr_state_str(next));
	rdpdr->state = next;
	return TRUE;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_try_send_device_list_announce_request(rdpdrPlugin* rdpdr);

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_send_device_list_remove_request(rdpdrPlugin* rdpdr, UINT32 count, UINT32 ids[])
{
	UINT32 i;
	wStream* s;

	WINPR_ASSERT(rdpdr);
	WINPR_ASSERT(ids || (count == 0));

	if (count == 0)
		return CHANNEL_RC_OK;

	if (!rdpdr_check_extended_pdu_flag(rdpdr, RDPDR_DEVICE_REMOVE_PDUS))
		return CHANNEL_RC_OK;

	s = Stream_New(NULL, count * sizeof(UINT32) + 8);

	if (!s)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "Stream_New failed!");
		return CHANNEL_RC_NO_MEMORY;
	}

	Stream_Write_UINT16(s, RDPDR_CTYP_CORE);
	Stream_Write_UINT16(s, PAKID_CORE_DEVICELIST_REMOVE);
	Stream_Write_UINT32(s, count);

	for (i = 0; i < count; i++)
		Stream_Write_UINT32(s, ids[i]);

	Stream_SealLength(s);
	return rdpdr_send(rdpdr, s);
}

#if defined(_UWP) || defined(__IOS__)

void first_hotplug(rdpdrPlugin* rdpdr)
{
}

static DWORD WINAPI drive_hotplug_thread_func(LPVOID arg)
{
	return CHANNEL_RC_OK;
}

static UINT drive_hotplug_thread_terminate(rdpdrPlugin* rdpdr)
{
	return CHANNEL_RC_OK;
}

#elif _WIN32

BOOL check_path(const char* path)
{
	UINT type = GetDriveTypeA(path);

	if (!(type == DRIVE_FIXED || type == DRIVE_REMOVABLE || type == DRIVE_CDROM ||
	      type == DRIVE_REMOTE))
		return FALSE;

	return GetVolumeInformationA(path, NULL, 0, NULL, NULL, NULL, NULL, 0);
}

void first_hotplug(rdpdrPlugin* rdpdr)
{
	size_t i;
	DWORD unitmask = GetLogicalDrives();

	for (i = 0; i < 26; i++)
	{
		if (unitmask & 0x01)
		{
			char drive_path[] = { 'c', ':', '\\', '\0' };
			char drive_name[] = { 'c', '\0' };
			RDPDR_DRIVE drive = { 0 };
			drive_path[0] = 'A' + (char)i;
			drive_name[0] = 'A' + (char)i;

			if (check_path(drive_path))
			{
				drive.Type = RDPDR_DTYP_FILESYSTEM;
				drive.Path = drive_path;
				drive.Name = drive_name;
				drive.automount = TRUE;
				devman_load_device_service(rdpdr->devman, (const RDPDR_DEVICE*)&drive,
				                           rdpdr->rdpcontext);
			}
		}

		unitmask = unitmask >> 1;
	}
}

LRESULT CALLBACK hotplug_proc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	rdpdrPlugin* rdpdr;
	PDEV_BROADCAST_HDR lpdb = (PDEV_BROADCAST_HDR)lParam;
	UINT error;
	rdpdr = (rdpdrPlugin*)GetWindowLongPtr(hWnd, GWLP_USERDATA);

	switch (Msg)
	{
		case WM_DEVICECHANGE:
			switch (wParam)
			{
				case DBT_DEVICEARRIVAL:
					if (lpdb->dbch_devicetype == DBT_DEVTYP_VOLUME)
					{
						PDEV_BROADCAST_VOLUME lpdbv = (PDEV_BROADCAST_VOLUME)lpdb;
						DWORD unitmask = lpdbv->dbcv_unitmask;
						int i;

						for (i = 0; i < 26; i++)
						{
							if (unitmask & 0x01)
							{
								char drive_path[] = { 'c', ':', '/', '\0' };
								char drive_name[] = { 'c', '\0' };
								drive_path[0] = 'A' + (char)i;
								drive_name[0] = 'A' + (char)i;

								if (check_path(drive_path))
								{
									RDPDR_DRIVE drive = { 0 };

									drive.Type = RDPDR_DTYP_FILESYSTEM;
									drive.Path = drive_path;
									drive.automount = TRUE;
									drive.Name = drive_name;
									devman_load_device_service(rdpdr->devman,
									                           (const RDPDR_DEVICE*)&drive,
									                           rdpdr->rdpcontext);
									rdpdr_try_send_device_list_announce_request(rdpdr);
								}
							}

							unitmask = unitmask >> 1;
						}
					}

					break;

				case DBT_DEVICEREMOVECOMPLETE:
					if (lpdb->dbch_devicetype == DBT_DEVTYP_VOLUME)
					{
						PDEV_BROADCAST_VOLUME lpdbv = (PDEV_BROADCAST_VOLUME)lpdb;
						DWORD unitmask = lpdbv->dbcv_unitmask;
						int i, j, count;
						char drive_name_upper, drive_name_lower;
						ULONG_PTR* keys = NULL;
						DEVICE_DRIVE_EXT* device_ext;
						UINT32 ids[1];

						for (i = 0; i < 26; i++)
						{
							if (unitmask & 0x01)
							{
								drive_name_upper = 'A' + i;
								drive_name_lower = 'a' + i;
								count = ListDictionary_GetKeys(rdpdr->devman->devices, &keys);

								for (j = 0; j < count; j++)
								{
									device_ext = (DEVICE_DRIVE_EXT*)ListDictionary_GetItemValue(
									    rdpdr->devman->devices, (void*)keys[j]);

									if (device_ext->device.type != RDPDR_DTYP_FILESYSTEM)
										continue;

									if (device_ext->path[0] == drive_name_upper ||
									    device_ext->path[0] == drive_name_lower)
									{
										if (device_ext->automount)
										{
											devman_unregister_device(rdpdr->devman, (void*)keys[j]);
											ids[0] = keys[j];

											if ((error = rdpdr_send_device_list_remove_request(
											         rdpdr, 1, ids)))
											{
												// dont end on error, just report ?
												WLog_Print(
												    rdpdr->log, WLOG_ERROR,
												    "rdpdr_send_device_list_remove_request failed "
												    "with error %" PRIu32 "!",
												    error);
											}

											break;
										}
									}
								}

								free(keys);
							}

							unitmask = unitmask >> 1;
						}
					}

					break;

				default:
					break;
			}

			break;

		default:
			return DefWindowProc(hWnd, Msg, wParam, lParam);
	}

	return DefWindowProc(hWnd, Msg, wParam, lParam);
}

static DWORD WINAPI drive_hotplug_thread_func(LPVOID arg)
{
	rdpdrPlugin* rdpdr;
	WNDCLASSEX wnd_cls;
	HWND hwnd;
	MSG msg;
	BOOL bRet;
	DEV_BROADCAST_HANDLE NotificationFilter;
	HDEVNOTIFY hDevNotify;
	rdpdr = (rdpdrPlugin*)arg;
	/* init windows class */
	wnd_cls.cbSize = sizeof(WNDCLASSEX);
	wnd_cls.style = CS_HREDRAW | CS_VREDRAW;
	wnd_cls.lpfnWndProc = hotplug_proc;
	wnd_cls.cbClsExtra = 0;
	wnd_cls.cbWndExtra = 0;
	wnd_cls.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wnd_cls.hCursor = NULL;
	wnd_cls.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wnd_cls.lpszMenuName = NULL;
	wnd_cls.lpszClassName = L"DRIVE_HOTPLUG";
	wnd_cls.hInstance = NULL;
	wnd_cls.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	RegisterClassEx(&wnd_cls);
	/* create window */
	hwnd = CreateWindowEx(0, L"DRIVE_HOTPLUG", NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL);
	SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG_PTR)rdpdr);
	rdpdr->hotplug_wnd = hwnd;
	/* register device interface to hwnd */
	NotificationFilter.dbch_size = sizeof(DEV_BROADCAST_HANDLE);
	NotificationFilter.dbch_devicetype = DBT_DEVTYP_HANDLE;
	hDevNotify = RegisterDeviceNotification(hwnd, &NotificationFilter, DEVICE_NOTIFY_WINDOW_HANDLE);

	/* message loop */
	while ((bRet = GetMessage(&msg, 0, 0, 0)) != 0)
	{
		if (bRet == -1)
		{
			break;
		}
		else
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	UnregisterDeviceNotification(hDevNotify);
	return CHANNEL_RC_OK;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT drive_hotplug_thread_terminate(rdpdrPlugin* rdpdr)
{
	UINT error = CHANNEL_RC_OK;

	if (rdpdr->hotplug_wnd && !PostMessage(rdpdr->hotplug_wnd, WM_QUIT, 0, 0))
	{
		error = GetLastError();
		WLog_Print(rdpdr->log, WLOG_ERROR, "PostMessage failed with error %" PRIu32 "", error);
	}

	return error;
}

#elif defined(__MACOSX__)

#define MAX_USB_DEVICES 100

typedef struct _hotplug_dev
{
	char* path;
	BOOL to_add;
} hotplug_dev;

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT handle_hotplug(rdpdrPlugin* rdpdr)
{
	struct dirent* pDirent;
	DIR* pDir;
	char fullpath[PATH_MAX];
	char* szdir = (char*)"/Volumes";
	struct stat buf;
	hotplug_dev dev_array[MAX_USB_DEVICES];
	int count;
	DEVICE_DRIVE_EXT* device_ext;
	ULONG_PTR* keys = NULL;
	int i, j;
	int size = 0;
	UINT error;
	UINT32 ids[1];
	pDir = opendir(szdir);

	if (pDir == NULL)
	{
		printf("Cannot open directory\n");
		return ERROR_OPEN_FAILED;
	}

	while ((pDirent = readdir(pDir)) != NULL)
	{
		if (pDirent->d_name[0] != '.')
		{
			sprintf_s(fullpath, ARRAYSIZE(fullpath), "%s/%s", szdir, pDirent->d_name);
			if (stat(fullpath, &buf) != 0)
				continue;

			if (S_ISDIR(buf.st_mode))
			{
				dev_array[size].path = _strdup(fullpath);

				if (!dev_array[size].path)
				{
					closedir(pDir);
					error = CHANNEL_RC_NO_MEMORY;
					goto cleanup;
				}

				dev_array[size++].to_add = TRUE;
			}
		}
	}

	closedir(pDir);
	/* delete removed devices */
	count = ListDictionary_GetKeys(rdpdr->devman->devices, &keys);

	for (j = 0; j < count; j++)
	{
		char* path = NULL;
		BOOL dev_found = FALSE;
		device_ext =
		    (DEVICE_DRIVE_EXT*)ListDictionary_GetItemValue(rdpdr->devman->devices, (void*)keys[j]);

		if (!device_ext || !device_ext->automount)
			continue;

		if (device_ext->device.type != RDPDR_DTYP_FILESYSTEM)
			continue;

		if (device_ext->path == NULL)
			continue;

		if (ConvertFromUnicode(CP_UTF8, 0, device_ext->path, -1, &path, 0, NULL, FALSE) <= 0)
			continue;

		/* not plugable device */
		if (strstr(path, "/Volumes/") == NULL)
		{
			free(path);
			continue;
		}

		for (i = 0; i < size; i++)
		{
			if (strstr(path, dev_array[i].path) != NULL)
			{
				dev_found = TRUE;
				dev_array[i].to_add = FALSE;
				break;
			}
		}

		free(path);

		if (!dev_found)
		{
			devman_unregister_device(rdpdr->devman, (void*)keys[j]);
			ids[0] = keys[j];

			if ((error = rdpdr_send_device_list_remove_request(rdpdr, 1, ids)))
			{
				WLog_Print(rdpdr->log, WLOG_ERROR,
				           "rdpdr_send_device_list_remove_request failed with error %" PRIu32 "!",
				           error);
				goto cleanup;
			}
		}
	}

	/* add new devices */
	for (i = 0; i < size; i++)
	{
		if (dev_array[i].to_add)
		{
			RDPDR_DRIVE drive = { 0 };
			char* name;

			drive.Type = RDPDR_DTYP_FILESYSTEM;
			drive.Path = dev_array[i].path;
			drive.automount = TRUE;
			name = strrchr(drive.Path, '/') + 1;
			drive.Name = name;

			if (!drive.Name)
			{
				error = CHANNEL_RC_NO_MEMORY;
				goto cleanup;
			}

			if ((error = devman_load_device_service(rdpdr->devman, (RDPDR_DEVICE*)&drive,
			                                        rdpdr->rdpcontext)))
			{
				WLog_Print(rdpdr->log, WLOG_ERROR, "devman_load_device_service failed!");
				error = CHANNEL_RC_NO_MEMORY;
				goto cleanup;
			}
		}
	}

cleanup:
	free(keys);

	for (i = 0; i < size; i++)
		free(dev_array[i].path);

	return error;
}

static void drive_hotplug_fsevent_callback(ConstFSEventStreamRef streamRef,
                                           void* clientCallBackInfo, size_t numEvents,
                                           void* eventPaths,
                                           const FSEventStreamEventFlags eventFlags[],
                                           const FSEventStreamEventId eventIds[])
{
	rdpdrPlugin* rdpdr;
	size_t i;
	UINT error;
	char** paths = (char**)eventPaths;
	rdpdr = (rdpdrPlugin*)clientCallBackInfo;

	for (i = 0; i < numEvents; i++)
	{
		if (strcmp(paths[i], "/Volumes/") == 0)
		{
			if ((error = handle_hotplug(rdpdr)))
			{
				WLog_Print(rdpdr->log, WLOG_ERROR, "handle_hotplug failed with error %" PRIu32 "!",
				           error);
			}
			else
				rdpdr_try_send_device_list_announce_request(rdpdr);

			return;
		}
	}
}

void first_hotplug(rdpdrPlugin* rdpdr)
{
	UINT error;

	if ((error = handle_hotplug(rdpdr)))
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "handle_hotplug failed with error %" PRIu32 "!", error);
	}
}

static DWORD WINAPI drive_hotplug_thread_func(LPVOID arg)
{
	rdpdrPlugin* rdpdr;
	FSEventStreamRef fsev;
	rdpdr = (rdpdrPlugin*)arg;
	CFStringRef path = CFSTR("/Volumes/");
	CFArrayRef pathsToWatch = CFArrayCreate(kCFAllocatorMalloc, (const void**)&path, 1, NULL);
	FSEventStreamContext ctx;
	ZeroMemory(&ctx, sizeof(ctx));
	ctx.info = arg;
	fsev =
	    FSEventStreamCreate(kCFAllocatorMalloc, drive_hotplug_fsevent_callback, &ctx, pathsToWatch,
	                        kFSEventStreamEventIdSinceNow, 1, kFSEventStreamCreateFlagNone);
	rdpdr->runLoop = CFRunLoopGetCurrent();
	FSEventStreamScheduleWithRunLoop(fsev, rdpdr->runLoop, kCFRunLoopDefaultMode);
	FSEventStreamStart(fsev);
	CFRunLoopRun();
	FSEventStreamStop(fsev);
	FSEventStreamRelease(fsev);
	ExitThread(CHANNEL_RC_OK);
	return CHANNEL_RC_OK;
}

#else

static const char* automountLocations[] = { "/run/user/%lu/gvfs", "/run/media/%s", "/media/%s",
	                                        "/media", "/mnt" };

static BOOL isAutomountLocation(const char* path)
{
	const size_t nrLocations = sizeof(automountLocations) / sizeof(automountLocations[0]);
	size_t x;
	char buffer[MAX_PATH] = { 0 };
	uid_t uid = getuid();
	char uname[MAX_PATH] = { 0 };
	ULONG size = sizeof(uname) - 1;

	if (!GetUserNameExA(NameSamCompatible, uname, &size))
		return FALSE;

	if (!path)
		return FALSE;

	for (x = 0; x < nrLocations; x++)
	{
		const char* location = automountLocations[x];
		size_t length;

		if (strstr(location, "%lu"))
			snprintf(buffer, sizeof(buffer), location, (unsigned long)uid);
		else if (strstr(location, "%s"))
			snprintf(buffer, sizeof(buffer), location, uname);
		else
			snprintf(buffer, sizeof(buffer), "%s", location);

		length = strnlen(buffer, sizeof(buffer));

		if (strncmp(buffer, path, length) == 0)
		{
			const char* rest = &path[length];

			/* Only consider mount locations with max depth of 1 below the
			 * base path or the base path itself. */
			if (*rest == '\0')
				return TRUE;
			else if (*rest == '/')
			{
				const char* token = strstr(&rest[1], "/");

				if (!token || (token[1] == '\0'))
					return TRUE;
			}
		}
	}

	return FALSE;
}

#define MAX_USB_DEVICES 100

typedef struct _hotplug_dev
{
	char* path;
	BOOL to_add;
} hotplug_dev;

static void handle_mountpoint(hotplug_dev* dev_array, size_t* size, const char* mountpoint)
{
	if (!mountpoint)
		return;
	/* copy hotpluged device mount point to the dev_array */
	if (isAutomountLocation(mountpoint) && (*size < MAX_USB_DEVICES))
	{
		dev_array[*size].path = _strdup(mountpoint);
		dev_array[*size].to_add = TRUE;
		(*size)++;
	}
}

#ifdef __sun
#include <sys/mnttab.h>
static UINT handle_platform_mounts_sun(wLog* log, hotplug_dev* dev_array, size_t* size)
{
	FILE* f;
	struct mnttab ent;
	f = fopen("/etc/mnttab", "r");
	if (f == NULL)
	{
		WLog_Print(log, WLOG_ERROR, "fopen failed!");
		return ERROR_OPEN_FAILED;
	}
	while (getmntent(f, &ent) == 0)
	{
		handle_mountpoint(dev_array, size, ent.mnt_mountp);
	}
	fclose(f);
	return ERROR_SUCCESS;
}
#endif

#if defined(__FreeBSD__) || defined(__OpenBSD__)
#include <sys/mount.h>
static UINT handle_platform_mounts_bsd(wLog* log, hotplug_dev* dev_array, size_t* size)
{
	int mntsize;
	size_t idx;
	struct statfs* mntbuf = NULL;

	mntsize = getmntinfo(&mntbuf, MNT_NOWAIT);
	if (!mntsize)
	{
		/* TODO: handle 'errno' */
		WLog_Print(log, WLOG_ERROR, "getmntinfo failed!");
		return ERROR_OPEN_FAILED;
	}
	for (idx = 0; idx < (size_t)mntsize; idx++)
	{
		handle_mountpoint(dev_array, size, mntbuf[idx].f_mntonname);
	}
	free(mntbuf);
	return ERROR_SUCCESS;
}
#endif

#if defined(__LINUX__) || defined(__linux__)
#include <mntent.h>
static UINT handle_platform_mounts_linux(wLog* log, hotplug_dev* dev_array, size_t* size)
{
	FILE* f;
	struct mntent* ent;
	f = fopen("/proc/mounts", "r");
	if (f == NULL)
	{
		WLog_Print(log, WLOG_ERROR, "fopen failed!");
		return ERROR_OPEN_FAILED;
	}
	while ((ent = getmntent(f)) != NULL)
	{
		handle_mountpoint(dev_array, size, ent->mnt_dir);
	}
	fclose(f);
	return ERROR_SUCCESS;
}
#endif

static UINT handle_platform_mounts(wLog* log, hotplug_dev* dev_array, size_t* size)
{
#ifdef __sun
	return handle_platform_mounts_sun(log, dev_array, size);
#elif defined(__FreeBSD__) || defined(__OpenBSD__)
	return handle_platform_mounts_bsd(log, dev_array, size);
#elif defined(__LINUX__) || defined(__linux__)
	return handle_platform_mounts_linux(log, dev_array, size);
#endif
	return ERROR_CALL_NOT_IMPLEMENTED;
}

static BOOL device_already_plugged(rdpdrPlugin* rdpdr, const hotplug_dev* device)
{
	BOOL rc = FALSE;
	int count, x;
	ULONG_PTR* keys = NULL;
	WCHAR* path = NULL;
	int status;

	if (!rdpdr || !device)
		return TRUE;
	if (!device->to_add)
		return TRUE;

	status = ConvertToUnicode(CP_UTF8, 0, device->path, -1, &path, 0);
	if (status <= 0)
		return TRUE;

	ListDictionary_Lock(rdpdr->devman->devices);
	count = ListDictionary_GetKeys(rdpdr->devman->devices, &keys);
	for (x = 0; x < count; x++)
	{
		DEVICE_DRIVE_EXT* device_ext =
		    (DEVICE_DRIVE_EXT*)ListDictionary_GetItemValue(rdpdr->devman->devices, (void*)keys[x]);

		if (!device_ext || (device_ext->device.type != RDPDR_DTYP_FILESYSTEM) || !device_ext->path)
			continue;
		if (_wcscmp(device_ext->path, path) == 0)
		{
			rc = TRUE;
			break;
		}
	}
	free(keys);
	free(path);
	ListDictionary_Unlock(rdpdr->devman->devices);
	return rc;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT handle_hotplug(rdpdrPlugin* rdpdr)
{
	hotplug_dev dev_array[MAX_USB_DEVICES] = { 0 };
	size_t i;
	size_t size = 0;
	int count, j;
	ULONG_PTR* keys = NULL;
	UINT32 ids[1];
	UINT error = ERROR_SUCCESS;

	error = handle_platform_mounts(rdpdr->log, dev_array, &size);

	/* delete removed devices */
	count = ListDictionary_GetKeys(rdpdr->devman->devices, &keys);

	for (j = 0; j < count; j++)
	{
		char* path = NULL;
		BOOL dev_found = FALSE;
		DEVICE_DRIVE_EXT* device_ext =
		    (DEVICE_DRIVE_EXT*)ListDictionary_GetItemValue(rdpdr->devman->devices, (void*)keys[j]);

		if (!device_ext || (device_ext->device.type != RDPDR_DTYP_FILESYSTEM) ||
		    !device_ext->path || !device_ext->automount)
			continue;

		ConvertFromUnicode(CP_UTF8, 0, device_ext->path, -1, &path, 0, NULL, NULL);

		if (!path)
			continue;

		/* not plugable device */
		if (isAutomountLocation(path))
		{
			for (i = 0; i < size; i++)
			{
				if (strstr(path, dev_array[i].path) != NULL)
				{
					dev_found = TRUE;
					dev_array[i].to_add = FALSE;
					break;
				}
			}
		}

		free(path);

		if (!dev_found)
		{
			devman_unregister_device(rdpdr->devman, (void*)keys[j]);
			ids[0] = keys[j];

			if ((error = rdpdr_send_device_list_remove_request(rdpdr, 1, ids)))
			{
				WLog_Print(rdpdr->log, WLOG_ERROR,
				           "rdpdr_send_device_list_remove_request failed with error %" PRIu32 "!",
				           error);
				goto cleanup;
			}
		}
	}

	/* add new devices */
	for (i = 0; i < size; i++)
	{
		if (!device_already_plugged(rdpdr, &dev_array[i]))
		{
			RDPDR_DRIVE drive = { 0 };
			char* name;

			drive.Type = RDPDR_DTYP_FILESYSTEM;
			drive.Path = dev_array[i].path;
			drive.automount = TRUE;
			name = strrchr(drive.Path, '/') + 1;
			drive.Name = name;

			if (!drive.Name)
			{
				WLog_Print(rdpdr->log, WLOG_ERROR, "_strdup failed!");
				error = CHANNEL_RC_NO_MEMORY;
				goto cleanup;
			}

			if ((error = devman_load_device_service(rdpdr->devman, (const RDPDR_DEVICE*)&drive,
			                                        rdpdr->rdpcontext)))
			{
				WLog_Print(rdpdr->log, WLOG_ERROR, "devman_load_device_service failed!");
				goto cleanup;
			}
		}
	}

cleanup:
	free(keys);

	for (i = 0; i < size; i++)
		free(dev_array[i].path);

	return error;
}

static void first_hotplug(rdpdrPlugin* rdpdr)
{
	UINT error;

	if ((error = handle_hotplug(rdpdr)))
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "handle_hotplug failed with error %" PRIu32 "!", error);
	}
}

static DWORD WINAPI drive_hotplug_thread_func(LPVOID arg)
{
	rdpdrPlugin* rdpdr;
	int mfd;
	fd_set rfds;
	struct timeval tv;
	int rv;
	UINT error = 0;
	DWORD status;
	rdpdr = (rdpdrPlugin*)arg;
	mfd = open("/proc/mounts", O_RDONLY, 0);

	if (mfd < 0)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "ERROR: Unable to open /proc/mounts.");
		error = ERROR_INTERNAL_ERROR;
		goto out;
	}

	FD_ZERO(&rfds);
	FD_SET(mfd, &rfds);
	tv.tv_sec = 1;
	tv.tv_usec = 0;

	while ((rv = select(mfd + 1, NULL, NULL, &rfds, &tv)) >= 0)
	{
		status = WaitForSingleObject(rdpdr->stopEvent, 0);

		if (status == WAIT_FAILED)
		{
			error = GetLastError();
			WLog_Print(rdpdr->log, WLOG_ERROR, "WaitForSingleObject failed with error %" PRIu32 "!",
			           error);
			goto out;
		}

		if (status == WAIT_OBJECT_0)
			break;

		if (FD_ISSET(mfd, &rfds))
		{
			/* file /proc/mounts changed, handle this */
			if ((error = handle_hotplug(rdpdr)))
			{
				WLog_Print(rdpdr->log, WLOG_ERROR, "handle_hotplug failed with error %" PRIu32 "!",
				           error);
				goto out;
			}
			else
				rdpdr_try_send_device_list_announce_request(rdpdr);
		}

		FD_ZERO(&rfds);
		FD_SET(mfd, &rfds);
		tv.tv_sec = 1;
		tv.tv_usec = 0;
	}

out:

	if (error && rdpdr->rdpcontext)
		setChannelError(rdpdr->rdpcontext, error, "drive_hotplug_thread_func reported an error");

	ExitThread(error);
	return error;
}

#endif

#if !defined(_WIN32) && !defined(__IOS__)
/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT drive_hotplug_thread_terminate(rdpdrPlugin* rdpdr)
{
	UINT error;

	if (rdpdr->hotplugThread)
	{
		SetEvent(rdpdr->stopEvent);
#ifdef __MACOSX__
		CFRunLoopStop(rdpdr->runLoop);
#endif

		if (WaitForSingleObject(rdpdr->hotplugThread, INFINITE) == WAIT_FAILED)
		{
			error = GetLastError();
			WLog_Print(rdpdr->log, WLOG_ERROR, "WaitForSingleObject failed with error %" PRIu32 "!",
			           error);
			return error;
		}

		CloseHandle(rdpdr->hotplugThread);
		CloseHandle(rdpdr->stopEvent);
		rdpdr->stopEvent = NULL;
		rdpdr->hotplugThread = NULL;
	}

	return CHANNEL_RC_OK;
}

#endif

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_process_connect(rdpdrPlugin* rdpdr)
{
	UINT32 index;
	rdpSettings* settings;
	UINT error = CHANNEL_RC_OK;
	rdpdr->devman = devman_new(rdpdr);

	if (!rdpdr->devman)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "devman_new failed!");
		return CHANNEL_RC_NO_MEMORY;
	}

	settings = (rdpSettings*)rdpdr->channelEntryPoints.pExtendedData;

	if (settings->ClientHostname)
		strncpy(rdpdr->computerName, settings->ClientHostname, sizeof(rdpdr->computerName) - 1);
	else
		strncpy(rdpdr->computerName, settings->ComputerName, sizeof(rdpdr->computerName) - 1);

	for (index = 0; index < settings->DeviceCount; index++)
	{
		const RDPDR_DEVICE* device = settings->DeviceArray[index];

		if (device->Type == RDPDR_DTYP_FILESYSTEM)
		{
			const char DynamicDrives[] = "DynamicDrives";
			const RDPDR_DRIVE* drive = (const RDPDR_DRIVE*)device;
			BOOL hotplugAll = strncmp(drive->Path, "*", 2) == 0;
			BOOL hotplugLater = strncmp(drive->Path, DynamicDrives, sizeof(DynamicDrives)) == 0;
			if (drive->Path && (hotplugAll || hotplugLater))
			{
				if (hotplugAll)
					first_hotplug(rdpdr);
#ifndef _WIN32

				if (!(rdpdr->stopEvent = CreateEvent(NULL, TRUE, FALSE, NULL)))
				{
					WLog_Print(rdpdr->log, WLOG_ERROR, "CreateEvent failed!");
					return ERROR_INTERNAL_ERROR;
				}

#endif

				if (!(rdpdr->hotplugThread =
				          CreateThread(NULL, 0, drive_hotplug_thread_func, rdpdr, 0, NULL)))
				{
					WLog_Print(rdpdr->log, WLOG_ERROR, "CreateThread failed!");
#ifndef _WIN32
					CloseHandle(rdpdr->stopEvent);
					rdpdr->stopEvent = NULL;
#endif
					return ERROR_INTERNAL_ERROR;
				}

				continue;
			}
		}

		if ((error = devman_load_device_service(rdpdr->devman, device, rdpdr->rdpcontext)))
		{
			WLog_Print(rdpdr->log, WLOG_ERROR,
			           "devman_load_device_service failed with error %" PRIu32 "!", error);
			return error;
		}
	}

	return error;
}

static UINT rdpdr_process_server_announce_request(rdpdrPlugin* rdpdr, wStream* s)
{
	if (Stream_GetRemainingLength(s) < 8)
		return ERROR_INVALID_DATA;

	Stream_Read_UINT16(s, rdpdr->serverVersionMajor);
	Stream_Read_UINT16(s, rdpdr->serverVersionMinor);
	Stream_Read_UINT32(s, rdpdr->clientID);
	rdpdr->sequenceId++;

	rdpdr->clientVersionMajor = MIN(RDPDR_VERSION_MAJOR, rdpdr->serverVersionMajor);
	rdpdr->clientVersionMinor = MIN(RDPDR_VERSION_MINOR_RDP10X, rdpdr->serverVersionMinor);
	WLog_Print(rdpdr->log, WLOG_DEBUG,
	           "[rdpdr] server announces version %" PRIu32 ".%" PRIu32 ", client uses %" PRIu32
	           ".%" PRIu32,
	           rdpdr->serverVersionMajor, rdpdr->serverVersionMinor, rdpdr->clientVersionMajor,
	           rdpdr->clientVersionMinor);

	return CHANNEL_RC_OK;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_send_client_announce_reply(rdpdrPlugin* rdpdr)
{
	wStream* s;

	WINPR_ASSERT(rdpdr);
	WINPR_ASSERT(rdpdr->state == RDPDR_CHANNEL_STATE_ANNOUNCE);
	rdpdr_state_advance(rdpdr, RDPDR_CHANNEL_STATE_ANNOUNCE_REPLY);

	s = Stream_New(NULL, 12);

	if (!s)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "Stream_New failed!");
		return CHANNEL_RC_NO_MEMORY;
	}

	Stream_Write_UINT16(s, RDPDR_CTYP_CORE);             /* Component (2 bytes) */
	Stream_Write_UINT16(s, PAKID_CORE_CLIENTID_CONFIRM); /* PacketId (2 bytes) */
	Stream_Write_UINT16(s, rdpdr->clientVersionMajor);
	Stream_Write_UINT16(s, rdpdr->clientVersionMinor);
	Stream_Write_UINT32(s, (UINT32)rdpdr->clientID);
	return rdpdr_send(rdpdr, s);
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_send_client_name_request(rdpdrPlugin* rdpdr)
{
	wStream* s;
	WCHAR* computerNameW = NULL;
	size_t computerNameLenW;

	WINPR_ASSERT(rdpdr);
	WINPR_ASSERT(rdpdr->state == RDPDR_CHANNEL_STATE_ANNOUNCE_REPLY);
	rdpdr_state_advance(rdpdr, RDPDR_CHANNEL_STATE_NAME_REQUEST);

	if (!rdpdr->computerName[0])
	{
		DWORD size = sizeof(rdpdr->computerName) - 1;
		GetComputerNameA(rdpdr->computerName, &size);
	}

	computerNameLenW = ConvertToUnicode(CP_UTF8, 0, rdpdr->computerName, -1, &computerNameW, 0) * 2;
	s = Stream_New(NULL, 16 + computerNameLenW + 2);

	if (!s)
	{
		free(computerNameW);
		WLog_Print(rdpdr->log, WLOG_ERROR, "Stream_New failed!");
		return CHANNEL_RC_NO_MEMORY;
	}

	Stream_Write_UINT16(s, RDPDR_CTYP_CORE);        /* Component (2 bytes) */
	Stream_Write_UINT16(s, PAKID_CORE_CLIENT_NAME); /* PacketId (2 bytes) */
	Stream_Write_UINT32(s, 1);                      /* unicodeFlag, 0 for ASCII and 1 for Unicode */
	Stream_Write_UINT32(s, 0);                      /* codePage, must be set to zero */
	Stream_Write_UINT32(s, computerNameLenW + 2);   /* computerNameLen, including null terminator */
	Stream_Write(s, computerNameW, computerNameLenW);
	Stream_Write_UINT16(s, 0); /* null terminator */
	free(computerNameW);
	return rdpdr_send(rdpdr, s);
}

static UINT rdpdr_process_server_clientid_confirm(rdpdrPlugin* rdpdr, wStream* s)
{
	UINT16 versionMajor;
	UINT16 versionMinor;
	UINT32 clientID;

	WINPR_ASSERT(rdpdr);
	WINPR_ASSERT(s);

	if (!Stream_CheckAndLogRequiredLengthWLog(rdpdr->log, s, 8))
		return ERROR_INVALID_DATA;

	Stream_Read_UINT16(s, versionMajor);
	Stream_Read_UINT16(s, versionMinor);
	Stream_Read_UINT32(s, clientID);

	if (versionMajor != rdpdr->clientVersionMajor || versionMinor != rdpdr->clientVersionMinor)
	{
		rdpdr->clientVersionMajor = versionMajor;
		rdpdr->clientVersionMinor = versionMinor;
	}

	if (clientID != rdpdr->clientID)
		rdpdr->clientID = clientID;

	return CHANNEL_RC_OK;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_send_device_list_announce_request(rdpdrPlugin* rdpdr, BOOL userLoggedOn)
{
	int i;
	BYTE c;
	size_t pos;
	int index;
	wStream* s;
	UINT32 count;
	size_t data_len;
	size_t count_pos;
	DEVICE* device;
	int keyCount;
	ULONG_PTR* pKeys = NULL;

	if (userLoggedOn)
		rdpdr->userLoggedOn = TRUE;

	s = Stream_New(NULL, 256);

	if (!s)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "Stream_New failed!");
		return CHANNEL_RC_NO_MEMORY;
	}

	Stream_Write_UINT16(s, RDPDR_CTYP_CORE);                /* Component (2 bytes) */
	Stream_Write_UINT16(s, PAKID_CORE_DEVICELIST_ANNOUNCE); /* PacketId (2 bytes) */
	count_pos = Stream_GetPosition(s);
	count = 0;
	Stream_Seek_UINT32(s); /* deviceCount */
	pKeys = NULL;
	keyCount = ListDictionary_GetKeys(rdpdr->devman->devices, &pKeys);

	for (index = 0; index < keyCount; index++)
	{
		device = (DEVICE*)ListDictionary_GetItemValue(rdpdr->devman->devices, (void*)pKeys[index]);

		/**
		 * 1. versionMinor 0x0005 doesn't send PAKID_CORE_USER_LOGGEDON
		 *    so all devices should be sent regardless of user_loggedon
		 * 2. smartcard devices should be always sent
		 * 3. other devices are sent only after user_loggedon
		 */

		if ((rdpdr->clientVersionMinor == RDPDR_VERSION_MINOR_RDP51) ||
		    (device->type == RDPDR_DTYP_SMARTCARD) || userLoggedOn)
		{
			data_len = (device->data == NULL ? 0 : Stream_GetPosition(device->data));

			if (!Stream_EnsureRemainingCapacity(s, 20 + data_len))
			{
				free(pKeys);
				Stream_Free(s, TRUE);
				WLog_Print(rdpdr->log, WLOG_ERROR, "Stream_EnsureRemainingCapacity failed!");
				return ERROR_INVALID_DATA;
			}

			Stream_Write_UINT32(s, device->type); /* deviceType */
			Stream_Write_UINT32(s, device->id);   /* deviceID */
			strncpy((char*)Stream_Pointer(s), device->name, 8);

			for (i = 0; i < 8; i++)
			{
				Stream_Peek_UINT8(s, c);

				if (c > 0x7F)
					Stream_Write_UINT8(s, '_');
				else
					Stream_Seek_UINT8(s);
			}

			Stream_Write_UINT32(s, data_len);

			if (data_len > 0)
				Stream_Write(s, Stream_Buffer(device->data), data_len);

			count++;
			WLog_Print(rdpdr->log, WLOG_INFO,
			           "registered device #%" PRIu32 ": %s (type=%" PRIu32 " id=%" PRIu32 ")",
			           count, device->name, device->type, device->id);
		}
	}

	free(pKeys);
	pos = Stream_GetPosition(s);
	Stream_SetPosition(s, count_pos);
	Stream_Write_UINT32(s, count);
	Stream_SetPosition(s, pos);
	Stream_SealLength(s);
	return rdpdr_send(rdpdr, s);
}

UINT rdpdr_try_send_device_list_announce_request(rdpdrPlugin* rdpdr)
{
	WINPR_ASSERT(rdpdr);
	if (rdpdr->state != RDPDR_CHANNEL_STATE_USER_LOGGEDON)
	{
		WLog_Print(rdpdr->log, WLOG_DEBUG,
		           "hotplug event received, but channel [RDPDR] is not ready (state %s), ignoring.",
		           rdpdr_state_str(rdpdr->state));
		return CHANNEL_RC_OK;
	}
	return rdpdr_send_device_list_announce_request(rdpdr, TRUE);
}

static UINT dummy_irp_response(rdpdrPlugin* rdpdr, wStream* s)
{

	UINT32 DeviceId;
	UINT32 FileId;
	UINT32 CompletionId;

	wStream* output = Stream_New(NULL, 256); // RDPDR_DEVICE_IO_RESPONSE_LENGTH
	if (!output)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "Stream_New failed!");
		return CHANNEL_RC_NO_MEMORY;
	}

	Stream_SetPosition(s, 4); /* see "rdpdr_process_receive" */

	Stream_Read_UINT32(s, DeviceId);     /* DeviceId (4 bytes) */
	Stream_Read_UINT32(s, FileId);       /* FileId (4 bytes) */
	Stream_Read_UINT32(s, CompletionId); /* CompletionId (4 bytes) */

	Stream_Write_UINT16(output, RDPDR_CTYP_CORE);                /* Component (2 bytes) */
	Stream_Write_UINT16(output, PAKID_CORE_DEVICE_IOCOMPLETION); /* PacketId (2 bytes) */
	Stream_Write_UINT32(output, DeviceId);                       /* DeviceId (4 bytes) */
	Stream_Write_UINT32(output, CompletionId);                   /* CompletionId (4 bytes) */
	Stream_Write_UINT32(output, STATUS_UNSUCCESSFUL);            /* IoStatus (4 bytes) */

	Stream_Zero(output, 256 - RDPDR_DEVICE_IO_RESPONSE_LENGTH);
	// or usage
	// Stream_Write_UINT32(output, 0); /* Length */
	// Stream_Write_UINT8(output, 0);  /* Padding */

	return rdpdr_send(rdpdr, output);
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_process_irp(rdpdrPlugin* rdpdr, wStream* s)
{
	IRP* irp;
	UINT error = CHANNEL_RC_OK;
	irp = irp_new(rdpdr->devman, s, rdpdr->log, &error);

	if (!irp)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "irp_new failed with %" PRIu32 "!", error);

		if (error == CHANNEL_RC_OK)
		{
			return dummy_irp_response(rdpdr, s);
		}

		return error;
	}

	IFCALLRET(irp->device->IRPRequest, error, irp->device, irp);

	if (error != CHANNEL_RC_OK)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "device->IRPRequest failed with error %" PRIu32 "",
		           error);
	}

	return error;
}

static UINT rdpdr_process_component(rdpdrPlugin* rdpdr, UINT16 component, UINT16 packetId,
                                    wStream* s)
{
	UINT32 type;
	DEVICE* device;

	switch (component)
	{
		case RDPDR_CTYP_PRN:
			type = RDPDR_DTYP_PRINT;
			break;

		default:
			return ERROR_INVALID_DATA;
	}

	device = devman_get_device_by_type(rdpdr->devman, type);

	if (!device)
		return ERROR_INVALID_PARAMETER;

	return IFCALLRESULT(ERROR_INVALID_PARAMETER, device->CustomComponentRequest, device, component,
	                    packetId, s);
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_process_init(rdpdrPlugin* rdpdr)
{
	int index;
	int keyCount;
	DEVICE* device;
	ULONG_PTR* pKeys = NULL;
	UINT error = CHANNEL_RC_OK;

	rdpdr->userLoggedOn = FALSE; /* reset possible received state */
	pKeys = NULL;
	keyCount = ListDictionary_GetKeys(rdpdr->devman->devices, &pKeys);

	for (index = 0; index < keyCount; index++)
	{
		device = (DEVICE*)ListDictionary_GetItemValue(rdpdr->devman->devices, (void*)pKeys[index]);
		IFCALLRET(device->Init, error, device);

		if (error != CHANNEL_RC_OK)
		{
			WLog_Print(rdpdr->log, WLOG_ERROR, "Init failed!");
			free(pKeys);
			return error;
		}
	}

	free(pKeys);
	return CHANNEL_RC_OK;
}

static BOOL state_match(enum RDPDR_CHANNEL_STATE state, size_t count, va_list ap)
{
	for (size_t x = 0; x < count; x++)
	{
		enum RDPDR_CHANNEL_STATE cur = va_arg(ap, enum RDPDR_CHANNEL_STATE);
		if (state == cur)
			return TRUE;
	}
	return FALSE;
}

static const char* state_str(size_t count, va_list ap, char* buffer, size_t size)
{
	for (size_t x = 0; x < count; x++)
	{
		enum RDPDR_CHANNEL_STATE cur = va_arg(ap, enum RDPDR_CHANNEL_STATE);
		const char* curstr = rdpdr_state_str(cur);
		winpr_str_append(curstr, buffer, size, "|");
	}
	return buffer;
}

static BOOL rdpdr_state_check(rdpdrPlugin* rdpdr, UINT16 packetid, enum RDPDR_CHANNEL_STATE next,
                              size_t count, ...)
{
	va_list ap;
	WINPR_ASSERT(rdpdr);

	va_start(ap, count);
	BOOL rc = state_match(rdpdr->state, count, ap);
	va_end(ap);

	if (!rc)
	{
		const char* strstate = rdpdr_state_str(rdpdr->state);
		char buffer[256] = { 0 };

		va_start(ap, count);
		state_str(count, ap, buffer, sizeof(buffer));
		va_end(ap);

		WLog_Print(rdpdr->log, WLOG_ERROR,
		           "channel [RDPDR] received %s, expected states [%s] but have state %s, aborting.",
		           rdpdr_packetid_string(packetid), buffer, strstate);

		rdpdr_state_advance(rdpdr, RDPDR_CHANNEL_STATE_INITIAL);
		return FALSE;
	}
	return rdpdr_state_advance(rdpdr, next);
}

static BOOL rdpdr_check_channel_state(rdpdrPlugin* rdpdr, UINT16 packetid)
{
	WINPR_ASSERT(rdpdr);

	switch (packetid)
	{
		case PAKID_CORE_SERVER_ANNOUNCE:
			/* windows servers sometimes send this message.
			 * it seems related to session login (e.g. first initialization for RDP/TLS style login,
			 * then reinitialize the channel after login successful
			 */
			rdpdr_state_advance(rdpdr, RDPDR_CHANNEL_STATE_INITIAL);
			return rdpdr_state_check(rdpdr, packetid, RDPDR_CHANNEL_STATE_ANNOUNCE, 1,
			                         RDPDR_CHANNEL_STATE_INITIAL);
		case PAKID_CORE_SERVER_CAPABILITY:
			return rdpdr_state_check(rdpdr, packetid, RDPDR_CHANNEL_STATE_SERVER_CAPS, 6,
			                         RDPDR_CHANNEL_STATE_NAME_REQUEST,
			                         RDPDR_CHANNEL_STATE_SERVER_CAPS, RDPDR_CHANNEL_STATE_READY,
			                         RDPDR_CHANNEL_STATE_CLIENT_CAPS, PAKID_CORE_CLIENTID_CONFIRM,
			                         PAKID_CORE_USER_LOGGEDON);
		case PAKID_CORE_CLIENTID_CONFIRM:
			return rdpdr_state_check(rdpdr, packetid, RDPDR_CHANNEL_STATE_CLIENTID_CONFIRM, 3,
			                         RDPDR_CHANNEL_STATE_CLIENT_CAPS, RDPDR_CHANNEL_STATE_READY,
			                         RDPDR_CHANNEL_STATE_USER_LOGGEDON);
		case PAKID_CORE_USER_LOGGEDON:
			if (!rdpdr_check_extended_pdu_flag(rdpdr, RDPDR_USER_LOGGEDON_PDU))
				return FALSE;

			return rdpdr_state_check(
			    rdpdr, packetid, RDPDR_CHANNEL_STATE_USER_LOGGEDON, 4,
			    RDPDR_CHANNEL_STATE_NAME_REQUEST, RDPDR_CHANNEL_STATE_CLIENT_CAPS,
			    RDPDR_CHANNEL_STATE_CLIENTID_CONFIRM, RDPDR_CHANNEL_STATE_READY);
		default:
		{
			enum RDPDR_CHANNEL_STATE state = RDPDR_CHANNEL_STATE_READY;
			return rdpdr_state_check(rdpdr, packetid, state, 1, state);
		}
	}
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_process_receive(rdpdrPlugin* rdpdr, wStream* s)
{
	UINT16 component;
	UINT16 packetId;
	UINT32 deviceId;
	UINT32 status;
	UINT error = ERROR_INVALID_DATA;

	if (!rdpdr || !s)
		return CHANNEL_RC_NULL_DATA;

	if (Stream_GetRemainingLength(s) >= 4)
	{
		Stream_Read_UINT16(s, component); /* Component (2 bytes) */
		Stream_Read_UINT16(s, packetId);  /* PacketId (2 bytes) */

		if (component == RDPDR_CTYP_CORE)
		{
			if (!rdpdr_check_channel_state(rdpdr, packetId))
				return CHANNEL_RC_OK;

			switch (packetId)
			{
				case PAKID_CORE_SERVER_ANNOUNCE:
					if ((error = rdpdr_process_server_announce_request(rdpdr, s)))
					{
					}
					else if ((error = rdpdr_send_client_announce_reply(rdpdr)))
					{
						WLog_Print(rdpdr->log, WLOG_ERROR,
						           "rdpdr_send_client_announce_reply failed with error %" PRIu32 "",
						           error);
					}
					else if ((error = rdpdr_send_client_name_request(rdpdr)))
					{
						WLog_Print(rdpdr->log, WLOG_ERROR,
						           "rdpdr_send_client_name_request failed with error %" PRIu32 "",
						           error);
					}
					else if ((error = rdpdr_process_init(rdpdr)))
					{
						WLog_Print(rdpdr->log, WLOG_ERROR,
						           "rdpdr_process_init failed with error %" PRIu32 "", error);
					}

					break;

				case PAKID_CORE_SERVER_CAPABILITY:
					if ((error = rdpdr_process_capability_request(rdpdr, s)))
					{
					}
					else if ((error = rdpdr_send_capability_response(rdpdr)))
					{
						WLog_Print(rdpdr->log, WLOG_ERROR,
						           "rdpdr_send_capability_response failed with error %" PRIu32 "",
						           error);
					}

					break;

				case PAKID_CORE_CLIENTID_CONFIRM:
					if ((error = rdpdr_process_server_clientid_confirm(rdpdr, s)))
					{
					}
					else if ((error = rdpdr_send_device_list_announce_request(rdpdr, FALSE)))
					{
						WLog_Print(
						    rdpdr->log, WLOG_ERROR,
						    "rdpdr_send_device_list_announce_request failed with error %" PRIu32 "",
						    error);
					}
					else if (!rdpdr_state_advance(rdpdr, RDPDR_CHANNEL_STATE_READY))
					{
						error = ERROR_INTERNAL_ERROR;
					}
					break;

				case PAKID_CORE_USER_LOGGEDON:
					if ((error = rdpdr_send_device_list_announce_request(rdpdr, TRUE)))
					{
						WLog_Print(
						    rdpdr->log, WLOG_ERROR,
						    "rdpdr_send_device_list_announce_request failed with error %" PRIu32 "",
						    error);
					}
					else if (!rdpdr_state_advance(rdpdr, RDPDR_CHANNEL_STATE_READY))
					{
						error = ERROR_INTERNAL_ERROR;
					}

					break;

				case PAKID_CORE_DEVICE_REPLY:

					/* connect to a specific resource */
					if (Stream_GetRemainingLength(s) >= 8)
					{
						Stream_Read_UINT32(s, deviceId);
						Stream_Read_UINT32(s, status);
						error = CHANNEL_RC_OK;
					}

					break;

				case PAKID_CORE_DEVICE_IOREQUEST:
					if ((error = rdpdr_process_irp(rdpdr, s)))
					{
						WLog_Print(rdpdr->log, WLOG_ERROR,
						           "rdpdr_process_irp failed with error %" PRIu32 "", error);
						return error;
					}
					else
						s = NULL;

					break;

				default:
					WLog_Print(rdpdr->log, WLOG_ERROR,
					           "RDPDR_CTYP_CORE unknown PacketId: 0x%04" PRIX16 "", packetId);
					error = ERROR_INVALID_DATA;
					break;
			}
		}
		else
		{
			error = rdpdr_process_component(rdpdr, component, packetId, s);

			if (error != CHANNEL_RC_OK)
			{
				WLog_Print(rdpdr->log, WLOG_ERROR,
				           "Unknown message: Component: [0x%04" PRIX16 "] PacketId: [0x%04" PRIX16
				           "]",
				           component, packetId);
			}
		}
	}

	Stream_Free(s, TRUE);
	return error;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
UINT rdpdr_send(rdpdrPlugin* rdpdr, wStream* s)
{
	UINT status;
	rdpdrPlugin* plugin = (rdpdrPlugin*)rdpdr;

	if (!rdpdr || !s)
	{
		Stream_Free(s, TRUE);
		return CHANNEL_RC_NULL_DATA;
	}

	if (!plugin)
	{
		Stream_Free(s, TRUE);
		status = CHANNEL_RC_BAD_INIT_HANDLE;
	}
	else
	{
		status = plugin->channelEntryPoints.pVirtualChannelWriteEx(
		    plugin->InitHandle, plugin->OpenHandle, Stream_Buffer(s), (UINT32)Stream_GetPosition(s),
		    s);
	}

	if (status != CHANNEL_RC_OK)
	{
		Stream_Free(s, TRUE);
		WLog_Print(rdpdr->log, WLOG_ERROR, "pVirtualChannelWriteEx failed with %s [%08" PRIX32 "]",
		           WTSErrorToString(status), status);
	}

	return status;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_virtual_channel_event_data_received(rdpdrPlugin* rdpdr, void* pData,
                                                      UINT32 dataLength, UINT32 totalLength,
                                                      UINT32 dataFlags)
{
	wStream* data_in;

	if ((dataFlags & CHANNEL_FLAG_SUSPEND) || (dataFlags & CHANNEL_FLAG_RESUME))
	{
		/*
		 * According to MS-RDPBCGR 2.2.6.1, "All virtual channel traffic MUST be suspended.
		 * This flag is only valid in server-to-client virtual channel traffic. It MUST be
		 * ignored in client-to-server data." Thus it would be best practice to cease data
		 * transmission. However, simply returning here avoids a crash.
		 */
		return CHANNEL_RC_OK;
	}

	if (dataFlags & CHANNEL_FLAG_FIRST)
	{
		if (rdpdr->data_in != NULL)
			Stream_Free(rdpdr->data_in, TRUE);

		rdpdr->data_in = Stream_New(NULL, totalLength);

		if (!rdpdr->data_in)
		{
			WLog_Print(rdpdr->log, WLOG_ERROR, "Stream_New failed!");
			return CHANNEL_RC_NO_MEMORY;
		}
	}

	data_in = rdpdr->data_in;

	if (!Stream_EnsureRemainingCapacity(data_in, dataLength))
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "Stream_EnsureRemainingCapacity failed!");
		return ERROR_INVALID_DATA;
	}

	Stream_Write(data_in, pData, dataLength);

	if (dataFlags & CHANNEL_FLAG_LAST)
	{
		if (Stream_Capacity(data_in) != Stream_GetPosition(data_in))
		{
			WLog_Print(rdpdr->log, WLOG_ERROR,
			           "rdpdr_virtual_channel_event_data_received: read error");
			return ERROR_INTERNAL_ERROR;
		}

		rdpdr->data_in = NULL;
		Stream_SealLength(data_in);
		Stream_SetPosition(data_in, 0);

		if (!MessageQueue_Post(rdpdr->queue, NULL, 0, (void*)data_in, NULL))
		{
			WLog_Print(rdpdr->log, WLOG_ERROR, "MessageQueue_Post failed!");
			return ERROR_INTERNAL_ERROR;
		}
	}

	return CHANNEL_RC_OK;
}

static VOID VCAPITYPE rdpdr_virtual_channel_open_event_ex(LPVOID lpUserParam, DWORD openHandle,
                                                          UINT event, LPVOID pData,
                                                          UINT32 dataLength, UINT32 totalLength,
                                                          UINT32 dataFlags)
{
	UINT error = CHANNEL_RC_OK;
	rdpdrPlugin* rdpdr = (rdpdrPlugin*)lpUserParam;

	switch (event)
	{
		case CHANNEL_EVENT_DATA_RECEIVED:
			if (!rdpdr || !pData || (rdpdr->OpenHandle != openHandle))
			{
				WLog_Print(rdpdr->log, WLOG_ERROR, "error no match");
				return;
			}
			if ((error = rdpdr_virtual_channel_event_data_received(rdpdr, pData, dataLength,
			                                                       totalLength, dataFlags)))
				WLog_Print(rdpdr->log, WLOG_ERROR,
				           "rdpdr_virtual_channel_event_data_received failed with error %" PRIu32
				           "!",
				           error);

			break;

		case CHANNEL_EVENT_WRITE_CANCELLED:
		case CHANNEL_EVENT_WRITE_COMPLETE:
		{
			wStream* s = (wStream*)pData;
			Stream_Free(s, TRUE);
		}
		break;

		case CHANNEL_EVENT_USER:
			break;
	}

	if (error && rdpdr && rdpdr->rdpcontext)
		setChannelError(rdpdr->rdpcontext, error,
		                "rdpdr_virtual_channel_open_event_ex reported an error");

	return;
}

static DWORD WINAPI rdpdr_virtual_channel_client_thread(LPVOID arg)
{
	wStream* data;
	wMessage message;
	rdpdrPlugin* rdpdr = (rdpdrPlugin*)arg;
	UINT error;

	if (!rdpdr)
	{
		ExitThread((DWORD)CHANNEL_RC_NULL_DATA);
		return CHANNEL_RC_NULL_DATA;
	}

	if ((error = rdpdr_process_connect(rdpdr)))
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "rdpdr_process_connect failed with error %" PRIu32 "!",
		           error);

		if (rdpdr->rdpcontext)
			setChannelError(rdpdr->rdpcontext, error,
			                "rdpdr_virtual_channel_client_thread reported an error");

		ExitThread(error);
		return error;
	}

	while (1)
	{
		if (!MessageQueue_Wait(rdpdr->queue))
			break;

		if (MessageQueue_Peek(rdpdr->queue, &message, TRUE))
		{
			if (message.id == WMQ_QUIT)
				break;

			if (message.id == 0)
			{
				data = (wStream*)message.wParam;

				if ((error = rdpdr_process_receive(rdpdr, data)))
				{
					WLog_Print(rdpdr->log, WLOG_ERROR,
					           "rdpdr_process_receive failed with error %" PRIu32 "!", error);

					if (rdpdr->rdpcontext)
						setChannelError(rdpdr->rdpcontext, error,
						                "rdpdr_virtual_channel_client_thread reported an error");

					ExitThread((DWORD)error);
					return error;
				}
			}
		}
	}

	ExitThread(0);
	return 0;
}

static void queue_free(void* obj)
{
	wStream* s = obj;
	Stream_Free(s, TRUE);
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_virtual_channel_event_connected(rdpdrPlugin* rdpdr, LPVOID pData,
                                                  UINT32 dataLength)
{
	UINT32 status;
	status = rdpdr->channelEntryPoints.pVirtualChannelOpenEx(rdpdr->InitHandle, &rdpdr->OpenHandle,
	                                                         rdpdr->channelDef.name,
	                                                         rdpdr_virtual_channel_open_event_ex);

	if (status != CHANNEL_RC_OK)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "pVirtualChannelOpenEx failed with %s [%08" PRIX32 "]",
		           WTSErrorToString(status), status);
		return status;
	}

	rdpdr->queue = MessageQueue_New(NULL);

	if (!rdpdr->queue)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "MessageQueue_New failed!");
		return CHANNEL_RC_NO_MEMORY;
	}

	rdpdr->queue->object.fnObjectFree = queue_free;

	if (!(rdpdr->thread =
	          CreateThread(NULL, 0, rdpdr_virtual_channel_client_thread, (void*)rdpdr, 0, NULL)))
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "CreateThread failed!");
		return ERROR_INTERNAL_ERROR;
	}

	return CHANNEL_RC_OK;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT rdpdr_virtual_channel_event_disconnected(rdpdrPlugin* rdpdr)
{
	UINT error;

	if (rdpdr->OpenHandle == 0)
		return CHANNEL_RC_OK;

	if (MessageQueue_PostQuit(rdpdr->queue, 0) &&
	    (WaitForSingleObject(rdpdr->thread, INFINITE) == WAIT_FAILED))
	{
		error = GetLastError();
		WLog_Print(rdpdr->log, WLOG_ERROR, "WaitForSingleObject failed with error %" PRIu32 "!",
		           error);
		return error;
	}

	MessageQueue_Free(rdpdr->queue);
	CloseHandle(rdpdr->thread);
	rdpdr->queue = NULL;
	rdpdr->thread = NULL;

	if ((error = drive_hotplug_thread_terminate(rdpdr)))
	{
		WLog_Print(rdpdr->log, WLOG_ERROR,
		           "drive_hotplug_thread_terminate failed with error %" PRIu32 "!", error);
		return error;
	}

	error = rdpdr->channelEntryPoints.pVirtualChannelCloseEx(rdpdr->InitHandle, rdpdr->OpenHandle);

	if (CHANNEL_RC_OK != error)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "pVirtualChannelCloseEx failed with %s [%08" PRIX32 "]",
		           WTSErrorToString(error), error);
	}

	rdpdr->OpenHandle = 0;

	if (rdpdr->data_in)
	{
		Stream_Free(rdpdr->data_in, TRUE);
		rdpdr->data_in = NULL;
	}

	if (rdpdr->devman)
	{
		devman_free(rdpdr->devman);
		rdpdr->devman = NULL;
	}

	return error;
}

static void rdpdr_virtual_channel_event_terminated(rdpdrPlugin* rdpdr)
{
	rdpdr->InitHandle = 0;
	free(rdpdr);
}

static VOID VCAPITYPE rdpdr_virtual_channel_init_event_ex(LPVOID lpUserParam, LPVOID pInitHandle,
                                                          UINT event, LPVOID pData, UINT dataLength)
{
	UINT error = CHANNEL_RC_OK;
	rdpdrPlugin* rdpdr = (rdpdrPlugin*)lpUserParam;

	if (!rdpdr || (rdpdr->InitHandle != pInitHandle))
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "error no match");
		return;
	}

	switch (event)
	{
		case CHANNEL_EVENT_INITIALIZED:
			break;

		case CHANNEL_EVENT_CONNECTED:
			if ((error = rdpdr_virtual_channel_event_connected(rdpdr, pData, dataLength)))
				WLog_Print(rdpdr->log, WLOG_ERROR,
				           "rdpdr_virtual_channel_event_connected failed with error %" PRIu32 "!",
				           error);

			break;

		case CHANNEL_EVENT_DISCONNECTED:
			if ((error = rdpdr_virtual_channel_event_disconnected(rdpdr)))
				WLog_Print(rdpdr->log, WLOG_ERROR,
				           "rdpdr_virtual_channel_event_disconnected failed with error %" PRIu32
				           "!",
				           error);

			break;

		case CHANNEL_EVENT_TERMINATED:
			rdpdr_virtual_channel_event_terminated(rdpdr);
			break;

		case CHANNEL_EVENT_ATTACHED:
		case CHANNEL_EVENT_DETACHED:
		default:
			WLog_Print(rdpdr->log, WLOG_ERROR, "unknown event %" PRIu32 "!", event);
			break;
	}

	if (error && rdpdr->rdpcontext)
		setChannelError(rdpdr->rdpcontext, error,
		                "rdpdr_virtual_channel_init_event_ex reported an error");
}

/* rdpdr is always built-in */
#define TAG CHANNELS_TAG("rdpdr.client")
#define VirtualChannelEntryEx rdpdr_VirtualChannelEntryEx

BOOL VCAPITYPE VirtualChannelEntryEx(PCHANNEL_ENTRY_POINTS pEntryPoints, PVOID pInitHandle)
{
	UINT rc;
	rdpdrPlugin* rdpdr;
	CHANNEL_ENTRY_POINTS_FREERDP_EX* pEntryPointsEx;

	WINPR_ASSERT(pEntryPoints);
	WINPR_ASSERT(pInitHandle);

	rdpdr = (rdpdrPlugin*)calloc(1, sizeof(rdpdrPlugin));

	if (!rdpdr)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "calloc failed!");
		return FALSE;
	}
	rdpdr->log = WLog_Get(TAG);

	rdpdr->clientExtendedPDU =
	    RDPDR_DEVICE_REMOVE_PDUS | RDPDR_CLIENT_DISPLAY_NAME_PDU | RDPDR_USER_LOGGEDON_PDU;
	rdpdr->clientIOCode1 =
	    RDPDR_IRP_MJ_CREATE | RDPDR_IRP_MJ_CLEANUP | RDPDR_IRP_MJ_CLOSE | RDPDR_IRP_MJ_READ |
	    RDPDR_IRP_MJ_WRITE | RDPDR_IRP_MJ_FLUSH_BUFFERS | RDPDR_IRP_MJ_SHUTDOWN |
	    RDPDR_IRP_MJ_DEVICE_CONTROL | RDPDR_IRP_MJ_QUERY_VOLUME_INFORMATION |
	    RDPDR_IRP_MJ_SET_VOLUME_INFORMATION | RDPDR_IRP_MJ_QUERY_INFORMATION |
	    RDPDR_IRP_MJ_SET_INFORMATION | RDPDR_IRP_MJ_DIRECTORY_CONTROL | RDPDR_IRP_MJ_LOCK_CONTROL |
	    RDPDR_IRP_MJ_QUERY_SECURITY | RDPDR_IRP_MJ_SET_SECURITY;

	rdpdr->clientExtraFlags1 = ENABLE_ASYNCIO;

	rdpdr->channelDef.options =
	    CHANNEL_OPTION_INITIALIZED | CHANNEL_OPTION_ENCRYPT_RDP | CHANNEL_OPTION_COMPRESS_RDP;
	sprintf_s(rdpdr->channelDef.name, ARRAYSIZE(rdpdr->channelDef.name), "rdpdr");
	rdpdr->sequenceId = 0;
	pEntryPointsEx = (CHANNEL_ENTRY_POINTS_FREERDP_EX*)pEntryPoints;

	if ((pEntryPointsEx->cbSize >= sizeof(CHANNEL_ENTRY_POINTS_FREERDP_EX)) &&
	    (pEntryPointsEx->MagicNumber == FREERDP_CHANNEL_MAGIC_NUMBER))
	{
		rdpdr->rdpcontext = pEntryPointsEx->context;
	}

	CopyMemory(&(rdpdr->channelEntryPoints), pEntryPoints, sizeof(CHANNEL_ENTRY_POINTS_FREERDP_EX));
	rdpdr->InitHandle = pInitHandle;
	rc = rdpdr->channelEntryPoints.pVirtualChannelInitEx(
	    rdpdr, NULL, pInitHandle, &rdpdr->channelDef, 1, VIRTUAL_CHANNEL_VERSION_WIN2000,
	    rdpdr_virtual_channel_init_event_ex);

	if (CHANNEL_RC_OK != rc)
	{
		WLog_Print(rdpdr->log, WLOG_ERROR, "pVirtualChannelInitEx failed with %s [%08" PRIX32 "]",
		           WTSErrorToString(rc), rc);
		free(rdpdr);
		return FALSE;
	}

	return TRUE;
}
